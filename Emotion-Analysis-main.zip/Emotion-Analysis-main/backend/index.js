const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const RegisterModel = require('./models/register')

const app = express();
app.use(express.json())
app.use(cors())

mongoose.connect("/News-reader")

app.post('/register', (req, res)=>{
    RegisterModel.create(req.body)
    .then(userdata => res.json(userdata))
    .catch(err => res.json(err))
})

app.post('/login', (req, res)=>{
    const {email, password} = req.body;
    RegisterModel.findOne({email: email})
    .then(user =>{
        if(user){
            if(user.password === password){
                res.json("Sucess")
            } else {
                res.json("The password is incorrect")
            }
        } else{
            res.json("Email is not register")
        }
    })
})

app.listen(3001, ()=>{
    console.log("server is running")
})